# Trading Floor

The [Ghost](http://github.com/tryghost/ghost/) theme for http://investmentsoc.com . Developed from [Casper](https://github.com/TryGhost/Casper).
